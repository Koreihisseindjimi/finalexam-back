package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.model.OrderItem;

public interface OrderItemService {
    OrderItem createOrderItem(OrderItem orderItem);

    OrderItem getOrderItemById(UUID orderItemId);

    List<OrderItem> getAllOrderItems();

    OrderItem updateOrderItem(OrderItem orderItem);

    void deleteOrderItem(UUID orderItemId);
}
