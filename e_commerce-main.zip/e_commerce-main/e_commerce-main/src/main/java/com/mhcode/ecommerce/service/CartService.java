package com.mhcode.ecommerce.service;

import java.util.UUID;

import com.mhcode.ecommerce.model.Cart;

public interface CartService {
    Cart createCart(Cart cart);

    Cart getCartById(UUID cartId);

    Cart updateCart(Cart cart);

    void deleteCart(UUID cartId);
}