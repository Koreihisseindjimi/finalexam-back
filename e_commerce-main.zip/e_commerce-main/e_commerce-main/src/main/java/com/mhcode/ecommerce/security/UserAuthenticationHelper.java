package com.mhcode.ecommerce.security;

import com.mhcode.ecommerce.model.UserRole;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class UserAuthenticationHelper {
    static Logger logger = LoggerFactory.getLogger(UserAuthenticationHelper.class);

    public static  boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals(UserRole.ADMIN.toString()));
    }
    public static boolean isSysAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals(UserRole.SYS_ADMIN.toString()));
    }

    public  static boolean isAgent() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals(UserRole.AGENT.toString()));
    }
    public  static boolean isCustomer() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals(UserRole.CUSTOMER.toString()));
    }




    public static String  getUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (String)authentication.getPrincipal();

    }

    public static void  getUserCategory() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        logger.info(authentication.getAuthorities()+"");
    }

}
