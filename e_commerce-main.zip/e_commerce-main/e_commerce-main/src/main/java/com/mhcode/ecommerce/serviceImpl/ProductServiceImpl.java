package com.mhcode.ecommerce.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mhcode.ecommerce.model.Product;
import com.mhcode.ecommerce.repository.ProductRepository;
import com.mhcode.ecommerce.service.ProductService;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product getProductById(UUID productId) {
        return productRepository.findById(productId).orElse(null);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product updateProduct(Product product) {
        Product existingProduct = productRepository.findById(product.getId()).orElse(null);
        if (existingProduct != null) {
            existingProduct.setName(product.getName());
            existingProduct.setPrice(product.getPrice());
            existingProduct.setAvailableQuantity(product.getAvailableQuantity());
            if (product.getImageData() != null) {
                existingProduct.setImageData(product.getImageData());
            }
            if (product.getCategory() != null) {
                existingProduct.setCategory(product.getCategory());
            }
            return productRepository.save(existingProduct);
        }
        return null;
    }

    public double getItemPriceById(UUID id) {
        // Retrieve the product from the database
        Optional<Product> productOptional = productRepository.findById(id);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            // Return the price of the product
            return product.getPrice();
        } else {
            // If product is not found, return -1 or throw an exception
            return -1; // or throw new ProductNotFoundException("Product not found with id: " + id);
        }

    }

    @Override
    public void deleteProduct(UUID productId) {
        productRepository.deleteById(productId);
    }
}
