package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.dto.LoginRequest;
import com.mhcode.ecommerce.dto.LoginResponse;
import com.mhcode.ecommerce.dto.user.ChangePasswordRequest;
import com.mhcode.ecommerce.dto.user.ChangePasswordResponse;
import com.mhcode.ecommerce.dto.user.RegistrationReq;
import com.mhcode.ecommerce.dto.user.RegistrationResponse;
import com.mhcode.ecommerce.model.User;

public interface UserService {
    RegistrationResponse createUser(RegistrationReq user);
    LoginResponse login(LoginRequest loginRequest);
    ChangePasswordResponse changePassword(ChangePasswordRequest request);
    User getUserByUsername(String username);
    List<User> getAllUsers();
//    User updateUser(User user);
//    void deleteUser(UUID userId);


}
