package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.model.Order;

public interface OrderService {
    Order createOrder(Order order);

    Order getOrderById(UUID orderId);

    List<Order> getAllOrders();

    Order updateOrder(Order order);

    void deleteOrder(UUID orderId);
}
