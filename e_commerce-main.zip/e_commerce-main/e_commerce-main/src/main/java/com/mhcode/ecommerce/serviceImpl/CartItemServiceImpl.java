package com.mhcode.ecommerce.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mhcode.ecommerce.model.CartItem;
import com.mhcode.ecommerce.repository.CartItemRepository;
import com.mhcode.ecommerce.service.CartItemService;

import java.util.List;
import java.util.UUID;

@Service
public class CartItemServiceImpl implements CartItemService {

    @Autowired
    private CartItemRepository cartItemRepository;

    @Override
    public CartItem createCartItem(CartItem cartItem) {
        return cartItemRepository.save(cartItem);
    }

    @Override
    public CartItem getCartItemById(UUID cartItemId) {
        return cartItemRepository.findById(cartItemId).orElse(null);
    }

    @Override
    public List<CartItem> getAllCartItems() {
        return cartItemRepository.findAll();
    }

    @Override
    public CartItem updateCartItem(CartItem cartItem) {
        CartItem existingCartItem = cartItemRepository.findById(cartItem.getId()).orElse(null);

        if (existingCartItem != null) {
            existingCartItem.setQuantity(cartItem.getQuantity());
            existingCartItem.setCart(cartItem.getCart());
            existingCartItem.setProduct(cartItem.getProduct());

            return cartItemRepository.save(existingCartItem);
        }

        return null;
    }

    @Override
    public void deleteCartItem(UUID cartItemId) {
        cartItemRepository.deleteById(cartItemId);
    }
}