package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.model.Product;

public interface ProductService {
    Product createProduct(Product product);

    Product getProductById(UUID productId);

    List<Product> getAllProducts();

    Product updateProduct(Product product);

    void deleteProduct(UUID productId);

    double getItemPriceById(UUID id);
}