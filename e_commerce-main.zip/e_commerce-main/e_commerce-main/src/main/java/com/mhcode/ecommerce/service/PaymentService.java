package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.model.Payment;

public interface PaymentService {

    Payment createPayment(Payment payment);

    Payment getPaymentById(UUID paymentId);

    List<Payment> getAllPayments();

    Payment updatePayment(Payment payment);

    void deletePayment(UUID paymentId);
}
