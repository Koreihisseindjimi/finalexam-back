package com.mhcode.ecommerce.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mhcode.ecommerce.model.Payment;
import com.mhcode.ecommerce.repository.PaymentRepository;
import com.mhcode.ecommerce.service.PaymentService;

import java.util.List;
import java.util.UUID;

@Service
public class PaymentServiceImpl implements PaymentService {

 @Autowired
 private PaymentRepository paymentRepository;

 @Override
 public Payment createPayment(Payment payment) {
  return paymentRepository.save(payment);
 }

 @Override
 public Payment getPaymentById(UUID paymentId) {
  return paymentRepository.findById(paymentId).orElse(null);
 }

 @Override
 public List<Payment> getAllPayments() {
  return paymentRepository.findAll();
 }

 @Override
 public Payment updatePayment(Payment payment) {
  Payment existingPayment =
          paymentRepository.findById(payment.getId()).orElse(null);

  if (existingPayment != null) {
   existingPayment.setAmount(payment.getAmount());
   existingPayment.setPaymentDate(payment.getPaymentDate());
   existingPayment.setPaymentMethod(payment.getPaymentMethod());
   existingPayment.setOrder(payment.getOrder());

   return paymentRepository.save(existingPayment);
  }

  return null;
 }

 @Override
 public void deletePayment(UUID paymentId) {
  paymentRepository.deleteById(paymentId);
 }
}