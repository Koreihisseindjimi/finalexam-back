package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.model.Address;

public interface AddressService {
    Address createAddress(Address address);

    Address getAddressById(UUID addressId);

    List<Address> getAllAddresses();

    Address updateAddress(Address address);

    void deleteAddress(UUID addressId);
}