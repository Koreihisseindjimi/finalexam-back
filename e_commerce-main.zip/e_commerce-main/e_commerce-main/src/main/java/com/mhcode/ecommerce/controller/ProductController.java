package com.mhcode.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.mhcode.ecommerce.model.Category;
import com.mhcode.ecommerce.model.Product;
import com.mhcode.ecommerce.service.ProductService;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestParam("file") MultipartFile file,
                                                 @RequestParam("name") String name,
                                                 @RequestParam("price") double price,
                                                 @RequestParam("quantity") int quantity) {
        try {
            // Save the uploaded file
            byte[] imageData = file.getBytes();

            // Create a new Product object
            Product product = new Product();
            product.setName(name);
            product.setPrice(price);
            product.setAvailableQuantity(quantity);
            product.setImageData(imageData);

            Product savedProduct = productService.createProduct(product);
            return ResponseEntity.ok(savedProduct);
        } catch (IOException e) {
            // Handle file processing error
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable UUID id) {
        Product product = productService.getProductById(id);
        return ResponseEntity.ok(product);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable UUID id,
                                                 @RequestParam("file") MultipartFile file,
                                                 @RequestParam("name") String name,
                                                 @RequestParam("price") double price,
                                                 @RequestParam("quantity") int quantity,
                                                 @RequestParam("categoryId") UUID categoryId) {
        try {
            byte[] imageData = file.getBytes();

            Product product = new Product();
            product.setId(id);
            product.setName(name);
            product.setPrice(price);
            product.setAvailableQuantity(quantity);
            product.setImageData(imageData);
            product.setCategory(new Category(categoryId)); // Set the category with the provided categoryId

            Product updatedProduct = productService.updateProduct(product);
            if (updatedProduct != null) {
                return ResponseEntity.ok(updatedProduct);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (IOException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable UUID id) {
        productService.deleteProduct(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/price")
    public ResponseEntity<Double> getProductPriceById(@PathVariable UUID id) {
        double price = productService.getItemPriceById(id);
        if (price != -1) {
            return ResponseEntity.ok(price);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
