package com.mhcode.ecommerce.service;

import java.util.List;
import java.util.UUID;

import com.mhcode.ecommerce.model.CartItem;

public interface CartItemService {
    CartItem createCartItem(CartItem cartItem);

    CartItem getCartItemById(UUID cartItemId);

    List<CartItem> getAllCartItems();

    CartItem updateCartItem(CartItem cartItem);

    void deleteCartItem(UUID cartItemId);
}
