package com.mhcode.ecommerce.model;

public enum UserRole {
    AGENT,ADMIN,SYS_ADMIN,CUSTOMER
}
