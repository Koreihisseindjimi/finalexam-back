package com.mhcode.ecommerce.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mhcode.ecommerce.model.Order;
import com.mhcode.ecommerce.repository.OrderRepository;
import com.mhcode.ecommerce.service.OrderService;
import com.mhcode.ecommerce.service.PaymentService;
import com.mhcode.ecommerce.service.UserService;
import java.util.List;
import java.util.UUID;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private PaymentService paymentService;

    @Override
    public Order createOrder(Order order) {
        order.setPayment(paymentService.createPayment(order.getPayment()));
        return orderRepository.save(order);
    }

    @Override
    public Order getOrderById(UUID orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public Order updateOrder(Order order) {
        Order existingOrder = orderRepository.findById(order.getId()).orElse(null);
        if (existingOrder != null) {
            existingOrder.setStatus(order.getStatus());
            existingOrder.setTotalPrice(order.getTotalPrice());
            existingOrder.setOrderDate(order.getOrderDate());
            existingOrder.setOrderItems(order.getOrderItems());
            return orderRepository.save(existingOrder);
        }
        return null;
    }

    @Override
    public void deleteOrder(UUID orderId) {
        orderRepository.deleteById(orderId);
    }
}
