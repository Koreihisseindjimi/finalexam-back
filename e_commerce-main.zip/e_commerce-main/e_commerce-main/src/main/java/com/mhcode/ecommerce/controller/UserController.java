package com.mhcode.ecommerce.controller;

import com.mhcode.ecommerce.dto.LoginRequest;
import com.mhcode.ecommerce.dto.LoginResponse;
import com.mhcode.ecommerce.dto.user.ChangePasswordRequest;
import com.mhcode.ecommerce.dto.user.ChangePasswordResponse;
import com.mhcode.ecommerce.dto.user.RegistrationReq;
import com.mhcode.ecommerce.dto.user.RegistrationResponse;
import com.mhcode.ecommerce.model.User;
import com.mhcode.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

//@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<RegistrationResponse> createUser(@RequestBody RegistrationReq user) {
        RegistrationResponse createdUser = userService.createUser(user);
        return ResponseEntity.ok(createdUser);
    }

    @GetMapping("/login")
    public ResponseEntity<LoginResponse>login(LoginRequest request){
        LoginResponse response=userService.login(request);
        return ResponseEntity.ok(response);
    }
    @PostMapping("/change-password")
    public ResponseEntity<ChangePasswordResponse>changePassword(ChangePasswordRequest request){
        ChangePasswordResponse response=userService.changePassword(request);
        return ResponseEntity.ok(response);
    }

}
