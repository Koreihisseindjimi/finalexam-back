package com.mhcode.ecommerce.serviceImpl;

import com.mhcode.ecommerce.dto.LoginRequest;
import com.mhcode.ecommerce.dto.LoginResponse;
import com.mhcode.ecommerce.dto.user.ChangePasswordRequest;
import com.mhcode.ecommerce.dto.user.ChangePasswordResponse;
import com.mhcode.ecommerce.dto.user.RegistrationReq;
import com.mhcode.ecommerce.dto.user.RegistrationResponse;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Service;

import com.mhcode.ecommerce.model.User;
import com.mhcode.ecommerce.repository.UserRepository;
import com.mhcode.ecommerce.service.UserService;
import com.mhcode.ecommerce.util.PasswordUtil;

import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserServiceImpl implements UserService {

    private static final String SECRET_KEY = "0785481627";
    private String generateToken(String username, String role) {

        String secretKey = SECRET_KEY;
        List<GrantedAuthority> grantedAuthorities = AuthorityUtils
                .commaSeparatedStringToAuthorityList(role.toString());

        String token = Jwts.builder()
                .setId(username)
                .setSubject(username)
                .claim("authorities",
                        grantedAuthorities.stream()
                                .map(GrantedAuthority::getAuthority)
                                .collect(Collectors.toList()))
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 86400000)) // 24 hours
                .signWith(SignatureAlgorithm.HS512, secretKey.getBytes())
                .compact();

        return token;
    }

    @Autowired
    UserRepository userRepository;

    @Override
    public RegistrationResponse createUser(RegistrationReq request) {
        String password=PasswordUtil.hashPassword(request.getPassword());
        User user=new User();
        RegistrationResponse response=new RegistrationResponse();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(password);
        userRepository.save(user);
        response.setMessage("registered with success");
        response.setStatus(201);
        return response;
    }

    @Override
    public LoginResponse login(LoginRequest request) {
        LoginResponse response = new LoginResponse();
        try {
            // Check if the user exists
            User user = userRepository.findByUsername(request.getUsername());
            if (user == null) {
                response.setMessage("User not found");
                response.setHttpStatus(404); // Not Found
                return response;
            }

            // Hash the incoming password and compare with the stored one
            String hashedPassword = PasswordUtil.hashPassword(request.getPassword());
            if (!user.getPassword().equals(hashedPassword)) {
                response.setMessage("Invalid username or password");
                response.setHttpStatus(401); // Unauthorized
                return response;
            }

            // Login successful
            String token=generateToken(request.getUsername(), "CUSTOMER");
            response.setMessage("Login successful");
            response.setToken(token);
            response.setHttpStatus(200);
        } catch (Exception e) {
            // Handle unexpected errors
            response.setMessage("An error occurred during login: " + e.getMessage());
            response.setHttpStatus(500); // Internal Server Error
        }
        return response;
    }



    @Override
    public ChangePasswordResponse changePassword(ChangePasswordRequest request) {
        ChangePasswordResponse response = new ChangePasswordResponse();

        try {
            // Find user
            User user = userRepository.findByUsername(request.getUsername());
            if (user == null) {
                response.setMessage("User not found");
                response.setStatus(404);
                return response;
            }

            // Verify old password (using hashed password)
            String hashedOldPassword = PasswordUtil.hashPassword(request.getOldPassword());
            if (!user.getPassword().equals(hashedOldPassword)) {
                response.setMessage("Incorrect current password");
                response.setStatus(400);
                return response;
            }

            // Validate new password
            if (request.getNewPassword() == null || request.getNewPassword().length() < 8) {
                response.setMessage("New password must be at least 8 characters long");
                response.setStatus(400);
                return response;
            }

            // Hash and set new password
            String hashedNewPassword = PasswordUtil.hashPassword(request.getNewPassword());
            user.setPassword(hashedNewPassword);

            // Save updated user
            userRepository.save(user);

            response.setMessage("Password changed successfully");
            response.setStatus(200);
        } catch (Exception e) {
            response.setMessage("An error occurred: " + e.getMessage());
            response.setStatus(500);
        }

        return response;
    }

    @Override
    public User getUserByUsername(String username) {
        return null;
    }

    @Override
    public List<User> getAllUsers() {
        return List.of();
    }




}
