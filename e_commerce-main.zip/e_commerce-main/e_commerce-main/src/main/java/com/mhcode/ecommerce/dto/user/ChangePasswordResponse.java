package com.mhcode.ecommerce.dto.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChangePasswordResponse {
    private int status;
    private String message;
}
