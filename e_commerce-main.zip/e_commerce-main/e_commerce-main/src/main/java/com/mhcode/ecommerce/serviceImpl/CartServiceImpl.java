package com.mhcode.ecommerce.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mhcode.ecommerce.model.Cart;
import com.mhcode.ecommerce.repository.CartRepository;
import com.mhcode.ecommerce.service.CartService;

import java.util.UUID;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Override
    public Cart createCart(Cart cart) {
        return cartRepository.save(cart);
    }

    @Override
    public Cart getCartById(UUID cartId) {
        return cartRepository.findById(cartId).orElse(null);
    }

    @Override
    public Cart updateCart(Cart cart) {
        Cart existingCart = cartRepository.findById(cart.getId()).orElse(null);

        if (existingCart != null) {
            existingCart.setCartItems(cart.getCartItems());

            return cartRepository.save(existingCart);
        }

        return null;
    }

    @Override
    public void deleteCart(UUID cartId) {
        cartRepository.deleteById(cartId);
    }
}